package com.itany.mvc.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

// 该注解能放的位置，type 类  method 方法
@Target({ElementType.TYPE,ElementType.METHOD})
// 注解类型，runtime：可在运行时通过反射获取到
@Retention(RetentionPolicy.RUNTIME)
public @interface RequestMapping {

	String value();
	
}
