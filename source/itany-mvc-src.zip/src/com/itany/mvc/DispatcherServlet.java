package com.itany.mvc;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.alibaba.fastjson.JSON;
import com.itany.mvc.annotation.Configuration;
import com.itany.mvc.annotation.ResponseBody;
import com.itany.mvc.annotation.ResponseEntity;
import com.itany.mvc.config.ResourceHandlerRegistry;
import com.itany.mvc.config.WebConfigurer;
import com.itany.mvc.controller.MyConfig;
import com.itany.mvc.util.CommonsMultipartFile;
import com.itany.mvc.util.HandlerMapping;
import com.itany.mvc.util.HandlerMappingParser;
import com.itany.mvc.util.MvcHttpServletRequestWrapper;
import com.itany.mvc.util.PackageScanner;
import com.sun.mail.handlers.message_rfc822;

/**
 * 核心控制器
 *  
 * @author  崔译
 * @version  [V1.00, 2018-1-5]
 * @see  [相关类/方法]
 * @since V1.00
 */
@WebServlet(urlPatterns="*.do",
			loadOnStartup=1,
			initParams={
				@WebInitParam(name="suffex",value=".jsp"),
				@WebInitParam(name="prefix",value="/WEB-INF/pages/"),
			},
			name="dispatcherServlet"
)
public class DispatcherServlet extends HttpServlet{
	
	// key 存放url  value 是对应的方法
	private static Map<String, HandlerMapping> handlerMappings;
	
	private static  String suffex;
	private static  String prefix;
	private static List<Class> classes;
	@Override
	public void init(ServletConfig config) throws ServletException {
		suffex = config.getInitParameter("suffex");
		prefix = config.getInitParameter("prefix");
	}
	
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String realPath = request.getServletContext().getRealPath("WEB-INF"+File.separator+"classes");
		try {
			if(handlerMappings == null)
			{
				classes = PackageScanner.scanPackage(realPath);
				// 找带有reuqestmapping注解的类
				handlerMappings = HandlerMappingParser.parse(classes);
			}
		
			Method m= null;
			
			// 获取应用程序上下文
			String contextPath = request.getContextPath();
			// 获取请求地址
			String url = request.getRequestURL().toString();
			// 获取请求地址*部分
			url = url.substring(url.indexOf(contextPath) + contextPath.length(), url.lastIndexOf(".do"));
			
			//判断url是不是view-controller
			ResourceHandlerRegistry registry = new ResourceHandlerRegistry();
			//带有Configuration注解的目标类
			Class targetClass = null;
			//遍历所有类
			for (int i = 0; i < classes.size(); i++) {
				Class c = classes.get(i);
				Configuration config = (Configuration) c.getAnnotation(Configuration.class);
				// 如果带有Configuration注解
				if(config != null)
				{
					// 将其赋值给目标类
					targetClass = c;
				}
			}
			// 目标类存在
			if(targetClass != null)
			{
				Object obj = targetClass.newInstance();
				// 调用对应方法，读取view-controller
				((WebConfigurer)obj).addViewControllers(registry);
			}
			// 判断是否存在该配置
			if(registry.contains(url))
			{
				request.getRequestDispatcher(prefix + registry.get(url) + suffex)
					.forward(request, response);
				return;
			}
			
			
			// url 应该对应  某个java类中的某个方法
			HandlerMapping hm  = handlerMappings.get(url);
			
			// 如果没有找到mapping，说明url错误 404
			if(hm == null)
			{
				response.sendError(404);
				return;
			}
			Method method = hm.getMethod();
			
			// 执行方法，获取方法返回值
			Object returnValue = null;
			String contentType = request.getHeader("Content-Type");
			// 如果是文件上传
			if(contentType !=null && contentType.contains("multipart/form-data") )
			{
				// 使用第三方的jar包，commons-fileupload.jar 实现文件上传
				// 获取DiskFileItem的工厂
				DiskFileItemFactory factory = new DiskFileItemFactory();
				// 创建解析工具
				ServletFileUpload upload = new ServletFileUpload(factory);
				List<FileItem> fileItemList = upload.parseRequest(request);
				// 自定义上传的文件类
				CommonsMultipartFile multiFile = null;
				// 自定义Request类
				MvcHttpServletRequestWrapper mvcRequest = 
						new MvcHttpServletRequestWrapper(request);
				for (FileItem fi : fileItemList) {
					// 如果是普通输入框(如果非文件上传框)
					if(fi.isFormField())
					{
						// 放到request中
						mvcRequest.setParameter(fi.getFieldName(), fi.getString("UTF-8"));	
					}
					if(!fi.isFormField())
					{
						// 创建文件对象
						multiFile = new CommonsMultipartFile(fi);
					}
				}
				// 传入自定义Request和文件对象
				returnValue =  method.invoke(hm.getObj(),mvcRequest,response,multiFile);
				
			}else{
				// 传入request 和response对象
				returnValue =  method.invoke(hm.getObj(),request,response);
			}
			
			// 如果返回null，则什么事也不做
			if(returnValue == null)
			{
				return;
			}
			
			// 获取响应体
			ResponseBody body = method.getAnnotation(ResponseBody.class);
			// 如果返回值是响应体
			if(body != null)
			{
				// 转换成json 输出
				String jsonStr = JSON.toJSONString(returnValue);
				PrintWriter out = response.getWriter();
				out.print(jsonStr);
				return;
			}
			
			
			//如果响应类型为ResponseEntity
			if(returnValue instanceof ResponseEntity)
			{
				ResponseEntity entity = (ResponseEntity) returnValue;
				response.setContentType(entity.getHeaders().getMediaType().getType());
				response.addHeader("Content-Disposition", entity.getHeaders().getContentDisposition());
				ServletOutputStream out = response.getOutputStream();
				out.write(entity.getData());
				out.flush();
				return;
			}
			
			// 如果返回值类型是String
			if(returnValue instanceof String)
			{
				// 解析返回值
				ReturnVO vo = parseReturnValue(returnValue.toString());
				// 如果是重定向
				if(vo.isRedirect())
				{
					response.sendRedirect(request.getContextPath()+vo.getPath());
					return;
				}
				
				request.getRequestDispatcher(vo.getPath())
					   .forward(request, response);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	private ReturnVO parseReturnValue(String returnValue)
	{
		ReturnVO vo = new ReturnVO();
		vo.setRedirect(returnValue.startsWith("redirect:"));
		
		if(vo.isRedirect())
		{
			returnValue = returnValue.replace("redirect:", "");
		}
		
		if(!returnValue.endsWith(".do"))
		{
			returnValue = prefix + returnValue + suffex;
		}
		vo.setPath(returnValue);
		return vo;
	}
	
}

class ReturnVO{
	private boolean redirect;
	private String path;
	public ReturnVO(boolean redirect, String path) {
		super();
		this.redirect = redirect;
		this.path = path;
	}
	public ReturnVO() {
	}
	public boolean isRedirect() {
		return redirect;
	}
	public void setRedirect(boolean redirect) {
		this.redirect = redirect;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	
	
}
