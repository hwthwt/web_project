package com.itany.mvc.util;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.itany.mvc.annotation.RequestMapping;

/**
 * 
 * <请求映射解析器>
 *  
 * @author  崔译
 * @version  [V1.00, 2018-1-5]
 * @see  [相关类/方法]
 * @since V1.00
 */
public class HandlerMappingParser {

	/**
	 * 
	 * <解析方法>
	 * <解析class类，将其中的方法进行映射>
	 * @param classes
	 * @return 映射对象，key是url value是请求处理方法映射对象
	 * @throws Exception
	 * @see [com.itany.mvc.annotation.RequestMapping,com.itany.mvc.util.HandlerMapping]
	 */
	public static Map<String, HandlerMapping> parse(List<Class> classes) throws Exception {
		// 创建最终结果
		Map<String, HandlerMapping> result = new HashMap<String, HandlerMapping>();
		// 循环参数中的class集合
		for (int i = 0; i < classes.size(); i++) {
			Class c = classes.get(i);
			// 获取class类的RequestMapping注解
			RequestMapping mapping = (RequestMapping) c.getAnnotation(RequestMapping.class);
			
			if(mapping != null)
			{
				// 获取RequestMapping注解的value，作为url前缀
				String baseUrl = mapping.value();
				// 获取Class中所有的方法
				Method[] ms = c.getDeclaredMethods();
				// 遍历这些方法
				for (int j = 0; j < ms.length; j++) {
					Method m = ms[j];
					// 获取方法上的RequestMapping注解
					RequestMapping map = m.getAnnotation(RequestMapping.class);
					if(map != null)
					{
						// 方法注解上的url，作为后半部分
						String url = map.value();
						// 将前缀和后半部分拼接，组成完整url
						url  = baseUrl + url;
						// 创建请求处理方法映射对象
						HandlerMapping hm = new HandlerMapping(c.newInstance(), m);
						// 将对象和url映射到map中
						result.put(url, hm);
					}
						
				}
				
			}
		}
		
		return result;
	}

}
