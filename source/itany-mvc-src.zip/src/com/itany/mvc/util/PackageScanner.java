package com.itany.mvc.util;

import java.io.File;
import java.io.FilenameFilter;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * <包扫描器>
 *  扫描项目路径下的所有class文件
 * @author  崔译
 * @version  [V1.00, 2018-1-5]
 * @see  [相关类/方法]
 * @since V1.00
 */
public class PackageScanner {

	/**
	 * 所有class文件对应的class类的集合
	 */
	private static List<Class> classes = new ArrayList<Class>();

	/**
	 * 
	 * <扫包方法>
	 * <扫描路径下的所有class文件，返回对应的Class对象的集合>
	 * @param path 要扫描的路径
	 * @return 对应的Class对象的集合
	 * @throws Exception 当出现异常时，抛出此异常
	 * @see [类、类#方法、类#成员]
	 */
	public static List<Class> scanPackage(String path) throws Exception
	{
		scan(path,"");
		return classes;
	}
	
	/**
	 * 
	 * <递归扫描>
	 * <功能详细描述>
	 * @param dirPath 待扫描路径
	 * @param packageName 该路径下class所在的包
	 * @throws Exception 当出现异常时，抛出此异常
	 * @see [类、类#方法、类#成员]
	 */
	private static void scan(String dirPath,String packageName) throws Exception
	{
		// 根据路径创建File对象
		File dir = new File(dirPath);
		// 列出该目录下所有.class结尾的文件和子目录
		File[] files = dir.listFiles(new FilenameFilter() {
			@Override
			public boolean accept(File dir, String name) {
				File f = new File(dir.getAbsolutePath() + File.separator + name);
				return (name.endsWith(".class") || f.isDirectory());
			}
		});
		// 遍历目录下所有文件
		for (File f : files) {
			// 如果是目录，递归扫描
			if(f.isDirectory())
			{
				scan(f.getAbsolutePath(),packageName+"."+f.getName());
				continue;
			}
			
			// 获取class文件对应类的 类全名
			String name = packageName + "." + f.getName();
			// 截取掉文件后缀
			name = name.substring(1).replace(".class", "");
			// 通过反射加载对应的Class对象，并放入到集合中
			classes.add(Class.forName(name));
		}
	}
	
}
